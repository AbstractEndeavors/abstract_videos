import os
import whisper
